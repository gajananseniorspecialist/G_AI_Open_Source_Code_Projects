import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface SecurityEvent {
  id: number;
  endpoint_id: string;
  hostname: string;
  event_type: string;
  severity: string;
  process_name: string;
  details: string;
  timestamp: string;
}

export async function analyzeSecurityEvent(event: SecurityEvent) {
  const prompt = `
    You are a senior security analyst at a Next-Gen EDR company. 
    Analyze the following security event and provide:
    1. Risk Assessment (Low, Medium, High, Critical)
    2. Detailed Explanation of why this might be malicious or benign.
    3. Recommended Actions (e.g., Isolate endpoint, Kill process, Ignore).
    
    Event Details:
    - Hostname: ${event.hostname}
    - Event Type: ${event.event_type}
    - Severity: ${event.severity}
    - Process: ${event.process_name}
    - Details: ${event.details}
    - Timestamp: ${event.timestamp}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskLevel: { type: Type.STRING },
            analysis: { type: Type.STRING },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
            isMalicious: { type: Type.BOOLEAN }
          },
          required: ["riskLevel", "analysis", "recommendations", "isMalicious"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return {
      riskLevel: "Unknown",
      analysis: "Failed to perform AI analysis due to an error.",
      recommendations: ["Manual investigation required"],
      isMalicious: false
    };
  }
}
