export interface Endpoint {
  id: string;
  hostname: string;
  ip_address: string;
  os: string;
  status: 'online' | 'offline' | 'isolated';
  last_seen: string;
}

export interface SecurityEvent {
  id: number;
  endpoint_id: string;
  hostname: string;
  event_type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  process_name: string;
  details: string;
  timestamp: string;
  status: 'pending' | 'resolved' | 'investigating';
}

export interface AIAnalysis {
  riskLevel: string;
  analysis: string;
  recommendations: string[];
  isMalicious: boolean;
}
