import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Activity, 
  Monitor, 
  Search, 
  AlertTriangle, 
  Settings, 
  Menu, 
  X, 
  ChevronRight,
  Zap,
  Cpu,
  Globe,
  Lock,
  Terminal,
  BrainCircuit
} from 'lucide-react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useLocation 
} from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Components
import Dashboard from './components/Dashboard';
import Endpoints from './components/Endpoints';
import ThreatHunting from './components/ThreatHunting';
import AIAnalyst from './components/AIAnalyst';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const SidebarItem = ({ 
  to, 
  icon: Icon, 
  label, 
  active 
}: { 
  to: string; 
  icon: any; 
  label: string; 
  active: boolean 
}) => (
  <Link
    to={to}
    className={cn(
      "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group",
      active 
        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.1)]" 
        : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/50"
    )}
  >
    <Icon size={20} className={cn(active ? "text-emerald-400" : "text-zinc-500 group-hover:text-zinc-300")} />
    <span className="font-medium text-sm tracking-tight">{label}</span>
    {active && (
      <motion.div 
        layoutId="active-pill"
        className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.6)]"
      />
    )}
  </Link>
);

export default function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-zinc-100 font-sans selection:bg-emerald-500/30">
      {/* Background Grid Effect */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#1f1f23_1px,transparent_1px),linear-gradient(to_bottom,#1f1f23_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none opacity-20" />

      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed top-0 left-0 h-full bg-[#0D0D0E] border-r border-zinc-800/50 transition-all duration-300 z-50",
          isSidebarOpen ? "w-64" : "w-20"
        )}
      >
        <div className="flex flex-col h-full p-4">
          <div className="flex items-center gap-3 px-2 mb-10">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              <Shield className="text-black" size={24} strokeWidth={2.5} />
            </div>
            {isSidebarOpen && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex flex-col"
              >
                <span className="font-bold text-lg leading-none tracking-tighter">GAI SENTINEL</span>
                <span className="text-[10px] text-emerald-500 font-mono font-bold tracking-widest uppercase mt-1">NextGen EDR</span>
              </motion.div>
            )}
          </div>

          <nav className="flex-1 space-y-2">
            <SidebarItem 
              to="/" 
              icon={Activity} 
              label={isSidebarOpen ? "Dashboard" : ""} 
              active={location.pathname === "/"} 
            />
            <SidebarItem 
              to="/endpoints" 
              icon={Monitor} 
              label={isSidebarOpen ? "Endpoints" : ""} 
              active={location.pathname === "/endpoints"} 
            />
            <SidebarItem 
              to="/hunting" 
              icon={Search} 
              label={isSidebarOpen ? "Threat Hunting" : ""} 
              active={location.pathname === "/hunting"} 
            />
            <SidebarItem 
              to="/ai-analyst" 
              icon={BrainCircuit} 
              label={isSidebarOpen ? "AI Analyst" : ""} 
              active={location.pathname === "/ai-analyst"} 
            />
          </nav>

          <div className="mt-auto pt-4 border-t border-zinc-800/50">
            <SidebarItem 
              to="/settings" 
              icon={Settings} 
              label={isSidebarOpen ? "Settings" : ""} 
              active={location.pathname === "/settings"} 
            />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main 
        className={cn(
          "transition-all duration-300 min-h-screen",
          isSidebarOpen ? "pl-64" : "pl-20"
        )}
      >
        {/* Header */}
        <header className="sticky top-0 z-40 bg-[#0A0A0B]/80 backdrop-blur-md border-bottom border-zinc-800/50 px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-400 transition-colors"
            >
              {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="h-6 w-[1px] bg-zinc-800 mx-2" />
            <div className="flex items-center gap-2 text-xs font-mono text-zinc-500">
              <Globe size={14} />
              <span>GLOBAL STATUS:</span>
              <span className="text-emerald-500 font-bold">PROTECTED</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="flex flex-col items-end">
                <span className="text-zinc-500">CPU LOAD</span>
                <span className="text-zinc-300">12.4%</span>
              </div>
              <div className="w-16 h-1 bg-zinc-800 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 w-[12.4%]" />
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-800 border border-zinc-600 flex items-center justify-center text-[10px] font-bold">
              AD
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/endpoints" element={<Endpoints />} />
              <Route path="/hunting" element={<ThreatHunting />} />
              <Route path="/ai-analyst" element={<AIAnalyst />} />
              <Route path="/settings" element={<div className="text-zinc-500 italic">Settings module coming soon...</div>} />
            </Routes>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
