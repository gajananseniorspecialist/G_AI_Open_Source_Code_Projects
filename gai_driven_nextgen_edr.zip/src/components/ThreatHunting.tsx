import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Terminal, 
  ShieldAlert, 
  Info, 
  ShieldCheck,
  ChevronDown,
  Download,
  BrainCircuit,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { SecurityEvent } from '../types';
import { analyzeSecurityEvent } from '../services/geminiService';

export default function ThreatHunting() {
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState<SecurityEvent | null>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/events');
      const data = await res.json();
      setEvents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const handleAnalyze = async (event: SecurityEvent) => {
    setAnalyzing(true);
    setAnalysis(null);
    try {
      const result = await analyzeSecurityEvent(event);
      setAnalysis(result);
    } catch (err) {
      console.error(err);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">Threat Hunting</h1>
        <p className="text-zinc-500 text-sm">Query and analyze historical event data across the entire fleet.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Events List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-4 bg-[#111112] border border-zinc-800/50 p-2 rounded-2xl">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
              <input 
                type="text" 
                placeholder="Query events (e.g. process_name: 'powershell.exe')..."
                className="w-full bg-transparent border-none focus:ring-0 pl-12 pr-4 py-3 text-sm placeholder:text-zinc-600"
              />
            </div>
            <button className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl transition-colors text-sm font-bold">
              Run Query
            </button>
          </div>

          <div className="bg-[#111112] border border-zinc-800/50 rounded-2xl overflow-hidden">
            <div className="max-h-[600px] overflow-y-auto">
              <table className="w-full text-left border-collapse">
                <thead className="sticky top-0 z-10 bg-[#111112] border-b border-zinc-800/50">
                  <tr>
                    <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Time</th>
                    <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Endpoint</th>
                    <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Event</th>
                    <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Severity</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {events.map((event) => (
                    <tr 
                      key={event.id} 
                      onClick={() => setSelectedEvent(event)}
                      className={`group cursor-pointer transition-colors ${selectedEvent?.id === event.id ? 'bg-emerald-500/5' : 'hover:bg-zinc-800/20'}`}
                    >
                      <td className="px-6 py-4">
                        <span className="text-[11px] font-mono text-zinc-500">{format(new Date(event.timestamp), 'HH:mm:ss')}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold text-zinc-300">{event.hostname}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-zinc-200">{event.process_name}</span>
                          <span className="text-[10px] text-zinc-500 truncate max-w-[200px]">{event.event_type}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${
                          event.severity === 'high' ? "text-rose-500 border-rose-500/20 bg-rose-500/5" : 
                          event.severity === 'medium' ? "text-amber-500 border-amber-500/20 bg-amber-500/5" : 
                          "text-emerald-500 border-emerald-500/20 bg-emerald-500/5"
                        }`}>
                          {event.severity}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Event Details Panel */}
        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {selectedEvent ? (
              <motion.div 
                key={selectedEvent.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-[#111112] border border-zinc-800/50 rounded-2xl p-6 h-full flex flex-col"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-bold text-lg">Event Details</h3>
                  <button 
                    onClick={() => setSelectedEvent(null)}
                    className="p-1.5 hover:bg-zinc-800 rounded-lg text-zinc-500"
                  >
                    <ChevronDown className="rotate-90" size={18} />
                  </button>
                </div>

                <div className="space-y-6 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase">Event ID</span>
                      <p className="text-xs font-mono text-zinc-300">EV-{selectedEvent.id.toString().padStart(6, '0')}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase">Timestamp</span>
                      <p className="text-xs font-mono text-zinc-300">{format(new Date(selectedEvent.timestamp), 'yyyy-MM-dd HH:mm:ss')}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono text-zinc-500 uppercase">Process Path</span>
                    <div className="bg-zinc-900/50 border border-zinc-800 p-3 rounded-xl font-mono text-[11px] text-zinc-300 break-all">
                      C:\Windows\System32\{selectedEvent.process_name}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono text-zinc-500 uppercase">Details</span>
                    <p className="text-sm text-zinc-300 leading-relaxed">{selectedEvent.details}</p>
                  </div>

                  <div className="pt-6 border-t border-zinc-800/50">
                    <button 
                      onClick={() => handleAnalyze(selectedEvent)}
                      disabled={analyzing}
                      className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
                    >
                      {analyzing ? (
                        <>
                          <RefreshCw size={18} className="animate-spin" />
                          <span>Analyzing with Gemini...</span>
                        </>
                      ) : (
                        <>
                          <BrainCircuit size={18} />
                          <span>AI Security Analysis</span>
                        </>
                      )}
                    </button>
                  </div>

                  {analysis && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={cn(
                        "mt-4 p-4 rounded-xl border",
                        analysis.isMalicious ? "bg-rose-500/5 border-rose-500/20" : "bg-emerald-500/5 border-emerald-500/20"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-3">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          analysis.isMalicious ? "bg-rose-500" : "bg-emerald-500"
                        )} />
                        <span className={cn(
                          "text-xs font-bold uppercase",
                          analysis.isMalicious ? "text-rose-500" : "text-emerald-500"
                        )}>
                          Risk Level: {analysis.riskLevel}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-300 leading-relaxed mb-4">{analysis.analysis}</p>
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase">Recommendations</span>
                        <ul className="space-y-1">
                          {analysis.recommendations.map((rec: string, i: number) => (
                            <li key={i} className="text-[11px] text-zinc-400 flex items-start gap-2">
                              <ArrowRight size={12} className="mt-0.5 text-emerald-500 shrink-0" />
                              {rec}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            ) : (
              <div className="bg-[#111112] border border-zinc-800/50 rounded-2xl p-6 h-full flex flex-col items-center justify-center text-center opacity-50">
                <Terminal size={48} className="text-zinc-800 mb-4" />
                <p className="text-sm text-zinc-500">Select an event from the list to view detailed forensics and AI analysis.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
