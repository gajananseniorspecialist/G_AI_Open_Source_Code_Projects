import React, { useState, useEffect } from 'react';
import { 
  Monitor, 
  Shield, 
  ShieldOff, 
  ShieldAlert, 
  MoreVertical, 
  Search,
  Filter,
  RefreshCw,
  Power,
  Lock,
  Terminal
} from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import { Endpoint } from '../types';

export default function Endpoints() {
  const [endpoints, setEndpoints] = useState<Endpoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchEndpoints = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/endpoints');
      const data = await res.json();
      setEndpoints(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEndpoints();
  }, []);

  const handleIsolate = async (id: string) => {
    try {
      const res = await fetch(`/api/endpoints/${id}/isolate`, { method: 'POST' });
      if (res.ok) {
        fetchEndpoints();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredEndpoints = endpoints.filter(e => 
    e.hostname.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.ip_address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold tracking-tight">Endpoints</h1>
          <p className="text-zinc-500 text-sm">Manage and monitor security status across all registered devices.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={fetchEndpoints}
            className="p-2.5 rounded-xl border border-zinc-800 hover:bg-zinc-800 transition-colors text-zinc-400"
          >
            <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 text-black font-bold rounded-xl hover:bg-emerald-400 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]">
            <Monitor size={18} />
            <span>Deploy Agent</span>
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex items-center gap-4 bg-[#111112] border border-zinc-800/50 p-2 rounded-2xl">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
          <input 
            type="text" 
            placeholder="Search by hostname or IP..."
            className="w-full bg-transparent border-none focus:ring-0 pl-12 pr-4 py-3 text-sm placeholder:text-zinc-600"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="h-8 w-[1px] bg-zinc-800" />
        <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-200 transition-colors">
          <Filter size={16} />
          <span>Filters</span>
        </button>
      </div>

      {/* Endpoints Table */}
      <div className="bg-[#111112] border border-zinc-800/50 rounded-2xl overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-zinc-800/50 bg-zinc-900/30">
              <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Status</th>
              <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Hostname</th>
              <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">IP Address</th>
              <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">OS</th>
              <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Last Seen</th>
              <th className="px-6 py-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/50">
            {filteredEndpoints.map((endpoint) => (
              <tr key={endpoint.id} className="group hover:bg-zinc-800/20 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      endpoint.status === 'online' ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]" : 
                      endpoint.status === 'isolated' ? "bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.4)]" : "bg-zinc-600"
                    }`} />
                    <span className={`text-xs font-bold uppercase tracking-tighter ${
                      endpoint.status === 'online' ? "text-emerald-500" : 
                      endpoint.status === 'isolated' ? "text-rose-500" : "text-zinc-500"
                    }`}>
                      {endpoint.status}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-zinc-200">{endpoint.hostname}</span>
                    <span className="text-[10px] font-mono text-zinc-500">{endpoint.id}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-xs font-mono text-zinc-400">{endpoint.ip_address}</span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-xs text-zinc-400">{endpoint.os}</span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-xs text-zinc-500">{format(new Date(endpoint.last_seen), 'MMM dd, HH:mm')}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {endpoint.status !== 'isolated' ? (
                      <button 
                        onClick={() => handleIsolate(endpoint.id)}
                        className="p-2 rounded-lg hover:bg-rose-500/10 text-zinc-500 hover:text-rose-500 transition-all"
                        title="Isolate Endpoint"
                      >
                        <Lock size={16} />
                      </button>
                    ) : (
                      <button 
                        className="p-2 rounded-lg hover:bg-emerald-500/10 text-zinc-500 hover:text-emerald-500 transition-all"
                        title="Reconnect Endpoint"
                      >
                        <RefreshCw size={16} />
                      </button>
                    )}
                    <button className="p-2 rounded-lg hover:bg-zinc-700 text-zinc-500 hover:text-zinc-200 transition-all">
                      <Terminal size={16} />
                    </button>
                    <button className="p-2 rounded-lg hover:bg-zinc-700 text-zinc-500 hover:text-zinc-200 transition-all">
                      <MoreVertical size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredEndpoints.length === 0 && (
          <div className="p-12 text-center">
            <Monitor size={48} className="mx-auto text-zinc-800 mb-4" />
            <p className="text-zinc-500">No endpoints found matching your search.</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
