import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  ShieldAlert, 
  ShieldCheck, 
  Monitor, 
  Zap, 
  ArrowUpRight,
  Clock,
  AlertCircle
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { format } from 'date-fns';
import { Endpoint, SecurityEvent } from '../types';

const StatCard = ({ label, value, subValue, icon: Icon, color }: any) => (
  <div className="bg-[#111112] border border-zinc-800/50 p-6 rounded-2xl relative overflow-hidden group">
    <div className={cn("absolute top-0 right-0 w-32 h-32 opacity-[0.03] -mr-8 -mt-8 transition-transform duration-500 group-hover:scale-110", color)}>
      <Icon size={128} />
    </div>
    <div className="flex items-start justify-between mb-4">
      <div className={cn("p-2.5 rounded-xl border", color.replace('text-', 'border-').replace('500', '500/20'), color.replace('text-', 'bg-').replace('500', '500/10'))}>
        <Icon size={20} className={color} />
      </div>
      <div className="flex items-center gap-1 text-[10px] font-mono text-zinc-500 bg-zinc-800/30 px-2 py-1 rounded-md">
        <ArrowUpRight size={10} />
        <span>+2.4%</span>
      </div>
    </div>
    <div className="space-y-1">
      <h3 className="text-zinc-500 text-xs font-medium uppercase tracking-wider">{label}</h3>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold tracking-tight">{value}</span>
        <span className="text-xs text-zinc-500 font-mono">{subValue}</span>
      </div>
    </div>
  </div>
);

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

const chartData = [
  { time: '00:00', threats: 4, activity: 40 },
  { time: '04:00', threats: 7, activity: 35 },
  { time: '08:00', threats: 5, activity: 85 },
  { time: '12:00', threats: 12, activity: 95 },
  { time: '16:00', threats: 8, activity: 70 },
  { time: '20:00', threats: 6, activity: 50 },
  { time: '23:59', threats: 5, activity: 45 },
];

export default function Dashboard() {
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [endpoints, setEndpoints] = useState<Endpoint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [evRes, epRes] = await Promise.all([
          fetch('/api/events'),
          fetch('/api/endpoints')
        ]);
        const evData = await evRes.json();
        const epData = await epRes.json();
        setEvents(evData);
        setEndpoints(epData);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const highSeverityCount = events.filter(e => e.severity === 'high' || e.severity === 'critical').length;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">Security Overview</h1>
        <p className="text-zinc-500 text-sm">Real-time autonomous monitoring and threat detection across all endpoints.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          label="Active Endpoints" 
          value={endpoints.filter(e => e.status === 'online').length} 
          subValue={`/ ${endpoints.length}`}
          icon={Monitor} 
          color="text-emerald-500" 
        />
        <StatCard 
          label="Threats Detected" 
          value={events.length} 
          subValue="LAST 24H"
          icon={ShieldAlert} 
          color="text-amber-500" 
        />
        <StatCard 
          label="High Severity" 
          value={highSeverityCount} 
          subValue="ACTION REQ."
          icon={AlertCircle} 
          color="text-rose-500" 
        />
        <StatCard 
          label="AI Automations" 
          value="142" 
          subValue="AUTONOMOUS"
          icon={Zap} 
          color="text-indigo-500" 
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#111112] border border-zinc-800/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold flex items-center gap-2">
              <Activity size={18} className="text-emerald-500" />
              Network Activity & Threats
            </h3>
            <div className="flex items-center gap-4 text-[10px] font-mono">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-zinc-400">ACTIVITY</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-rose-500" />
                <span className="text-zinc-400">THREATS</span>
              </div>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f1f23" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  stroke="#52525b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#52525b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0D0D0E', border: '1px solid #27272a', borderRadius: '8px' }}
                  itemStyle={{ fontSize: '12px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="activity" 
                  stroke="#10b981" 
                  fillOpacity={1} 
                  fill="url(#colorActivity)" 
                  strokeWidth={2}
                />
                <Area 
                  type="monotone" 
                  dataKey="threats" 
                  stroke="#f43f5e" 
                  fillOpacity={1} 
                  fill="url(#colorThreats)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#111112] border border-zinc-800/50 rounded-2xl p-6">
          <h3 className="font-bold flex items-center gap-2 mb-6">
            <ShieldCheck size={18} className="text-emerald-500" />
            Recent Alerts
          </h3>
          <div className="space-y-4">
            {events.slice(0, 5).map((event) => (
              <div key={event.id} className="flex gap-4 group cursor-pointer">
                <div className={cn(
                  "w-1 h-10 rounded-full shrink-0",
                  event.severity === 'high' ? "bg-rose-500" : 
                  event.severity === 'medium' ? "bg-amber-500" : "bg-emerald-500"
                )} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-bold truncate">{event.process_name}</span>
                    <span className="text-[10px] font-mono text-zinc-500">{format(new Date(event.timestamp), 'HH:mm')}</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 truncate">{event.details}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-mono text-zinc-500 uppercase">{event.hostname}</span>
                    <div className="w-1 h-1 rounded-full bg-zinc-700" />
                    <span className={cn(
                      "text-[9px] font-bold uppercase",
                      event.severity === 'high' ? "text-rose-500" : 
                      event.severity === 'medium' ? "text-amber-500" : "text-emerald-500"
                    )}>
                      {event.severity}
                    </span>
                  </div>
                </div>
              </div>
            ))}
            <button className="w-full py-2 mt-2 text-xs font-medium text-zinc-500 hover:text-zinc-300 transition-colors border border-zinc-800 rounded-lg hover:bg-zinc-800/50">
              View All Alerts
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
