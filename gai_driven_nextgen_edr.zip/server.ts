import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("edr.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS endpoints (
    id TEXT PRIMARY KEY,
    hostname TEXT NOT NULL,
    ip_address TEXT,
    os TEXT,
    status TEXT DEFAULT 'online',
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    endpoint_id TEXT,
    event_type TEXT,
    severity TEXT,
    process_name TEXT,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY(endpoint_id) REFERENCES endpoints(id)
  );
`);

// Seed initial data if empty
const endpointCount = db.prepare("SELECT COUNT(*) as count FROM endpoints").get() as { count: number };
if (endpointCount.count === 0) {
  const insertEndpoint = db.prepare("INSERT INTO endpoints (id, hostname, ip_address, os, status) VALUES (?, ?, ?, ?, ?)");
  insertEndpoint.run("ep-001", "WS-OFFICE-01", "192.168.1.15", "Windows 11", "online");
  insertEndpoint.run("ep-002", "SRV-PROD-SQL", "10.0.0.50", "Ubuntu 22.04 LTS", "online");
  insertEndpoint.run("ep-003", "MAC-DESIGN-04", "192.168.1.42", "macOS Sonoma", "offline");
  
  const insertEvent = db.prepare("INSERT INTO events (endpoint_id, event_type, severity, process_name, details) VALUES (?, ?, ?, ?, ?)");
  insertEvent.run("ep-001", "Process Start", "low", "chrome.exe", "User started browser");
  insertEvent.run("ep-002", "Network Connection", "medium", "ssh", "Inbound connection from 185.x.x.x");
  insertEvent.run("ep-001", "File Modification", "high", "unknown_binary.exe", "Modification of C:\\Windows\\System32\\drivers\\etc\\hosts");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/endpoints", (req, res) => {
    const endpoints = db.prepare("SELECT * FROM endpoints ORDER BY last_seen DESC").all();
    res.json(endpoints);
  });

  app.get("/api/events", (req, res) => {
    const events = db.prepare(`
      SELECT events.*, endpoints.hostname 
      FROM events 
      JOIN endpoints ON events.endpoint_id = endpoints.id 
      ORDER BY timestamp DESC 
      LIMIT 100
    `).all();
    res.json(events);
  });

  app.post("/api/events/analyze", (req, res) => {
    const { eventId } = req.body;
    // In a real app, we'd fetch the event and send it to Gemini.
    // For now, we'll just return a placeholder that the frontend will handle.
    res.json({ message: "Analysis requested" });
  });

  app.post("/api/endpoints/:id/isolate", (req, res) => {
    const { id } = req.params;
    db.prepare("UPDATE endpoints SET status = 'isolated' WHERE id = ?").run(id);
    res.json({ success: true, message: `Endpoint ${id} isolated.` });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
