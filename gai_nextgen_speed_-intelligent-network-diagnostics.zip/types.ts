
export enum TestStatus {
  IDLE = 'IDLE',
  MEASURING_LATENCY = 'MEASURING_LATENCY',
  MEASURING_DOWNLOAD = 'MEASURING_DOWNLOAD',
  ANALYZING = 'ANALYZING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface SpeedMetrics {
  downloadMbps: number;
  latencyMs: number;
  jitterMs: number;
  uploadMbps: number;
}

export interface GeminiInsight {
  title: string;
  summary: string;
  recommendations: string[];
  capabilityList: {
    label: string;
    status: 'excellent' | 'good' | 'fair' | 'poor';
  }[];
}
