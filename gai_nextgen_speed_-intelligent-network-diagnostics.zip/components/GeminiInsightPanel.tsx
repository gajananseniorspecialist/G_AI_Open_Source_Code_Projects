
import React from 'react';
import { GeminiInsight } from '../types';

interface GeminiInsightPanelProps {
  insight: GeminiInsight | null;
  isLoading: boolean;
}

const GeminiInsightPanel: React.FC<GeminiInsightPanelProps> = ({ insight, isLoading }) => {
  if (isLoading) {
    return (
      <div className="w-full max-w-2xl mt-12 p-6 bg-zinc-900/30 rounded-2xl border border-zinc-800/50 animate-pulse">
        <div className="h-6 w-48 bg-zinc-800 rounded mb-4"></div>
        <div className="space-y-2">
          <div className="h-4 w-full bg-zinc-800 rounded"></div>
          <div className="h-4 w-3/4 bg-zinc-800 rounded"></div>
        </div>
      </div>
    );
  }

  if (!insight) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'bg-emerald-500';
      case 'good': return 'bg-blue-500';
      case 'fair': return 'bg-yellow-500';
      case 'poor': return 'bg-red-500';
      default: return 'bg-zinc-500';
    }
  };

  return (
    <div className="w-full max-w-2xl mt-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="p-8 bg-zinc-900/50 rounded-3xl border border-zinc-800/50 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-indigo-500/10 rounded-lg">
            <svg className="w-5 h-5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white">{insight.title}</h2>
        </div>

        <p className="text-zinc-400 leading-relaxed mb-8">
          {insight.summary}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-4">Network Capabilities</h3>
            <div className="space-y-4">
              {insight.capabilityList.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <span className="text-zinc-300 text-sm">{item.label}</span>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${getStatusColor(item.status)}`}></div>
                    <span className="text-xs text-zinc-500 capitalize">{item.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-4">Pro Tips</h3>
            <ul className="space-y-3">
              {insight.recommendations.map((tip, idx) => (
                <li key={idx} className="flex gap-2 text-sm text-zinc-400">
                  <span className="text-indigo-500">•</span>
                  {tip}
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="flex justify-center pt-4 opacity-30 text-[10px] tracking-[0.2em] font-bold text-zinc-500 uppercase">
          Powered by Gemini 3 Flash
        </div>
      </div>
    </div>
  );
};

export default GeminiInsightPanel;
