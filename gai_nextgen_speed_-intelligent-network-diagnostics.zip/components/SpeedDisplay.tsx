
import React from 'react';

interface SpeedDisplayProps {
  value: number;
  isCalculating: boolean;
}

const SpeedDisplay: React.FC<SpeedDisplayProps> = ({ value, isCalculating }) => {
  return (
    <div className="flex flex-col items-center justify-center py-20 relative">
      <div className="flex items-baseline gap-2">
        <span className={`text-[120px] md:text-[220px] font-light leading-none tracking-tighter ${isCalculating ? 'opacity-50 animate-pulse' : 'text-white'}`}>
          {value === 0 ? '0' : value.toFixed(0)}
        </span>
        <div className="flex flex-col items-start">
          <span className="text-2xl md:text-4xl font-light text-zinc-400">Mbps</span>
        </div>
      </div>
      
      {isCalculating && (
        <div className="absolute inset-0 flex items-center justify-center -z-10">
          <div className="w-64 h-64 md:w-96 md:h-96 rounded-full border border-zinc-800 flex items-center justify-center">
             <div className="w-full h-full rounded-full border-2 border-transparent border-t-zinc-500 animate-spin" />
          </div>
        </div>
      )}
    </div>
  );
};

export default SpeedDisplay;
