
import React from 'react';

interface MetricsGridProps {
  latency: number;
  jitter: number;
  upload: number;
  isLoading: boolean;
}

const MetricsGrid: React.FC<MetricsGridProps> = ({ latency, jitter, upload, isLoading }) => {
  return (
    <div className="grid grid-cols-3 gap-8 w-full max-w-2xl px-4 border-t border-zinc-800 pt-8 mt-4">
      <div className="flex flex-col items-center">
        <span className="text-zinc-500 text-xs uppercase tracking-widest font-semibold mb-1">Latency</span>
        <div className="flex items-baseline gap-1">
          <span className={`text-2xl font-mono ${isLoading && !latency ? 'text-zinc-700' : 'text-zinc-200'}`}>
            {latency || '--'}
          </span>
          <span className="text-zinc-500 text-sm">ms</span>
        </div>
      </div>
      
      <div className="flex flex-col items-center">
        <span className="text-zinc-500 text-xs uppercase tracking-widest font-semibold mb-1">Jitter</span>
        <div className="flex items-baseline gap-1">
          <span className={`text-2xl font-mono ${isLoading && !jitter ? 'text-zinc-700' : 'text-zinc-200'}`}>
            {jitter || '--'}
          </span>
          <span className="text-zinc-500 text-sm">ms</span>
        </div>
      </div>

      <div className="flex flex-col items-center">
        <span className="text-zinc-500 text-xs uppercase tracking-widest font-semibold mb-1">Upload</span>
        <div className="flex items-baseline gap-1">
          <span className={`text-2xl font-mono ${isLoading && !upload ? 'text-zinc-700' : 'text-zinc-200'}`}>
            {upload || '--'}
          </span>
          <span className="text-zinc-500 text-sm">Mbps</span>
        </div>
      </div>
    </div>
  );
};

export default MetricsGrid;
