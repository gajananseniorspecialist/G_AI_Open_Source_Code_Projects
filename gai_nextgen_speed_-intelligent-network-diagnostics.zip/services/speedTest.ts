
// We use common high-availability assets that generally allow CORS for speed testing.
// Note: In a production environment, you'd use dedicated speed-test endpoints.
const DOWNLOAD_URLS = [
  'https://raw.githubusercontent.com/mdn/learning-area/master/javascript/oojs/json/superheroes.json',
  'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js',
  'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js'
];

const LATENCY_URL = 'https://www.google.com/favicon.ico';

export const measureLatency = async (): Promise<{ latency: number; jitter: number }> => {
  const pings: number[] = [];
  
  for (let i = 0; i < 5; i++) {
    const start = performance.now();
    try {
      await fetch(`${LATENCY_URL}?cache_bust=${Math.random()}`, { mode: 'no-cors' });
      const end = performance.now();
      pings.push(end - start);
    } catch (e) {
      console.error('Latency measurement failed', e);
    }
  }

  const averageLatency = pings.reduce((a, b) => a + b, 0) / pings.length;
  const jitter = Math.max(...pings) - Math.min(...pings);
  
  return { 
    latency: Math.round(averageLatency), 
    jitter: Math.round(jitter) 
  };
};

export const measureDownload = async (onProgress: (mbps: number) => void): Promise<number> => {
  let totalBytes = 0;
  let totalTime = 0;

  // We perform multiple small downloads to estimate throughput
  for (const url of DOWNLOAD_URLS) {
    const start = performance.now();
    try {
      const response = await fetch(`${url}?cb=${Date.now()}`, { cache: 'no-store' });
      const blob = await response.blob();
      const end = performance.now();
      
      const durationSeconds = (end - start) / 1000;
      const bitsLoaded = blob.size * 8;
      const mbps = (bitsLoaded / 1024 / 1024) / durationSeconds;
      
      totalBytes += blob.size;
      totalTime += durationSeconds;
      
      onProgress(mbps);
    } catch (e) {
      console.error('Download measurement failed for', url, e);
    }
  }

  const finalMbps = (totalBytes * 8 / 1024 / 1024) / totalTime;
  return Number(finalMbps.toFixed(1));
};
