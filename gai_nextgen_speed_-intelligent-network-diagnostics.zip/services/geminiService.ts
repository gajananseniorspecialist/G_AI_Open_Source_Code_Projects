
import { GoogleGenAI, Type } from "@google/genai";
import { SpeedMetrics, GeminiInsight } from "../types";

export const getNetworkInsights = async (metrics: SpeedMetrics): Promise<GeminiInsight> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Based on the following internet speed metrics, provide a concise diagnostic summary:
    - Download Speed: ${metrics.downloadMbps} Mbps
    - Latency: ${metrics.latencyMs} ms
    - Jitter: ${metrics.jitterMs} ms
    
    Tell the user what they can realistically do (4K streaming, pro gaming, basic browsing, etc.) and give 2-3 technical tips if the speed is sub-optimal.
    Return the response in JSON format.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          summary: { type: Type.STRING },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          capabilityList: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                status: { type: Type.STRING, description: "One of: excellent, good, fair, poor" }
              },
              required: ["label", "status"]
            }
          }
        },
        required: ["title", "summary", "recommendations", "capabilityList"]
      }
    }
  });

  try {
    const json = JSON.parse(response.text);
    return json as GeminiInsight;
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Insight generation failed");
  }
};
