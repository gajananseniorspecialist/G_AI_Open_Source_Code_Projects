
import { GoogleGenAI, Type } from "@google/genai";
import { Asset, Vulnerability, AIAnalysisResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeSecurityPosture(assets: Asset[], vulnerabilities: Vulnerability[]): Promise<AIAnalysisResponse> {
  const prompt = `
    Analyze the following security assets and vulnerabilities:
    Assets: ${JSON.stringify(assets)}
    Vulnerabilities: ${JSON.stringify(vulnerabilities)}
    
    Provide a comprehensive analysis including:
    1. A executive summary of the current security posture.
    2. A list of the top 3 critical priorities.
    3. A high-level remediation strategy.
    4. An assessment of the risk trend.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            priorities: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            remediationStrategy: { type: Type.STRING },
            riskTrend: { type: Type.STRING }
          },
          required: ["summary", "priorities", "remediationStrategy", "riskTrend"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return {
      summary: "Unable to generate AI analysis at this time. Please check your network connection.",
      priorities: ["Manual review required", "Check critical severity vulns first"],
      remediationStrategy: "Follow standard patching protocols.",
      riskTrend: "Unknown"
    };
  }
}

export async function getRemediationAdvice(vulnerability: Vulnerability): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide expert cybersecurity remediation advice for the following vulnerability: ${vulnerability.cveId} - ${vulnerability.title}. 
      Context: ${vulnerability.description}. 
      Keep it professional, technical, and concise.`,
    });
    return response.text;
  } catch (error) {
    return "Error generating AI advice.";
  }
}
