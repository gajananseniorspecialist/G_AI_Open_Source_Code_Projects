
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { DashboardCharts } from './components/DashboardCharts';
import { MOCK_ASSETS, MOCK_VULNS, SEVERITY_COLORS } from './constants';
import { Asset, Severity, AIAnalysisResponse } from './types';
import { analyzeSecurityPosture } from './services/geminiService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'assets' | 'vulnerabilities' | 'threats' | 'scans'>('dashboard');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResponse | null>(null);

  const handleRunAIAnalysis = async () => {
    setIsAnalyzing(true);
    const analysis = await analyzeSecurityPosture(MOCK_ASSETS, MOCK_VULNS);
    setAiAnalysis(analysis);
    setIsAnalyzing(false);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="h-16 fixed top-0 w-full glass-panel z-50 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">CyberVMDR</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={handleRunAIAnalysis}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 transition-all font-medium ${isAnalyzing ? 'animate-pulse opacity-75' : ''}`}
            disabled={isAnalyzing}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            {isAnalyzing ? 'Analyzing with Gemini...' : 'AI Security Insight'}
          </button>
          <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            <span className="text-sm font-medium">Global Network</span>
          </div>
        </div>
      </header>

      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="ml-64 pt-24 p-8">
        {/* Breadcrumb / Top Bar */}
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold capitalize text-white mb-2">{activeTab.replace('-', ' ')}</h2>
            <p className="text-slate-400">Environment: <span className="text-blue-400">Enterprise Core</span> | Monitoring 1,245 Assets</p>
          </div>
          <div className="flex gap-4">
            <div className="glass-panel px-4 py-2 rounded-lg text-center">
              <div className="text-2xl font-bold text-red-500">24</div>
              <div className="text-xs text-slate-400 uppercase tracking-tighter">Critical Risk</div>
            </div>
            <div className="glass-panel px-4 py-2 rounded-lg text-center">
              <div className="text-2xl font-bold text-orange-500">142</div>
              <div className="text-xs text-slate-400 uppercase tracking-tighter">High Alerts</div>
            </div>
          </div>
        </div>

        {/* AI Insight Section (Conditional) */}
        {aiAnalysis && (
          <div className="mb-8 p-6 rounded-xl border border-blue-500/30 bg-blue-600/5 animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                </div>
                <h3 className="text-xl font-bold text-blue-400">Gemini Security Intelligence</h3>
              </div>
              <button onClick={() => setAiAnalysis(null)} className="text-slate-500 hover:text-white">Close</button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-slate-300 uppercase tracking-widest">Executive Summary</h4>
                <p className="text-sm text-slate-400 leading-relaxed">{aiAnalysis.summary}</p>
              </div>
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-slate-300 uppercase tracking-widest">Top Priorities</h4>
                <ul className="space-y-2">
                  {aiAnalysis.priorities.map((p, i) => (
                    <li key={i} className="flex gap-3 text-sm text-slate-400">
                      <span className="text-blue-500 font-bold">{i+1}.</span> {p}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="text-sm font-semibold text-slate-300 uppercase tracking-widest">Remediation Path</h4>
                <p className="text-sm text-slate-400 leading-relaxed">{aiAnalysis.remediationStrategy}</p>
                <div className="mt-4 p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                  <span className="text-xs text-slate-500">Predicted Risk Trend:</span>
                  <div className="text-lg font-bold text-blue-400">{aiAnalysis.riskTrend}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Content Based on Tabs */}
        {activeTab === 'dashboard' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Total Assets', value: '1,245', sub: '+12 this week', color: 'blue' },
                { label: 'Vulnerabilities', value: '3,892', sub: '-5.2% trend', color: 'orange' },
                { label: 'Avg. MTTR', value: '14 days', sub: 'Target: 10 days', color: 'green' },
                { label: 'Risk Score', value: '68/100', sub: 'Critical Level', color: 'red' },
              ].map((stat, i) => (
                <div key={i} className="glass-panel p-6 rounded-xl hover:bg-slate-800/80 transition-all cursor-default group">
                  <div className="text-slate-400 text-sm font-medium mb-1 group-hover:text-slate-200">{stat.label}</div>
                  <div className={`text-2xl font-bold text-${stat.color}-500 mb-2`}>{stat.value}</div>
                  <div className="text-xs text-slate-500">{stat.sub}</div>
                </div>
              ))}
            </div>
            <DashboardCharts />
          </>
        )}

        {activeTab === 'assets' && (
          <div className="glass-panel rounded-xl overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-800/50 border-b border-slate-700">
                  <th className="px-6 py-4 font-semibold text-slate-300">Hostname</th>
                  <th className="px-6 py-4 font-semibold text-slate-300">IP Address</th>
                  <th className="px-6 py-4 font-semibold text-slate-300">OS</th>
                  <th className="px-6 py-4 font-semibold text-slate-300">Security Posture</th>
                  <th className="px-6 py-4 font-semibold text-slate-300">Last Scanned</th>
                  <th className="px-6 py-4 font-semibold text-slate-300">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {MOCK_ASSETS.map((asset) => (
                  <tr key={asset.id} className="hover:bg-slate-800/30 transition-all cursor-pointer">
                    <td className="px-6 py-4 font-medium text-white">{asset.hostname}</td>
                    <td className="px-6 py-4 text-slate-400">{asset.ip}</td>
                    <td className="px-6 py-4 text-slate-400">{asset.os}</td>
                    <td className="px-6 py-4">
                      <div className="flex gap-1">
                        <span className="w-3 h-3 rounded-full bg-red-500" title="Critical"></span>
                        <span className="text-xs text-slate-400">{asset.criticalCount} Critical</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-400">{asset.lastScan}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        asset.status === 'Online' ? 'bg-green-600/20 text-green-500' : 
                        asset.status === 'Offline' ? 'bg-slate-600/20 text-slate-500' : 'bg-blue-600/20 text-blue-500'
                      }`}>
                        {asset.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'vulnerabilities' && (
          <div className="space-y-4">
            <div className="flex gap-4 mb-6">
              <input 
                type="text" 
                placeholder="Search by CVE or Title..." 
                className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-slate-200 focus:outline-none focus:border-blue-500 transition-all"
              />
              <select className="bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-slate-200 outline-none">
                <option>All Severities</option>
                <option>Critical Only</option>
                <option>High and Above</option>
              </select>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {MOCK_VULNS.map((vuln) => (
                <div key={vuln.id} className="glass-panel p-5 rounded-xl border-l-4 border-l-red-600 hover:scale-[1.01] transition-all">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${SEVERITY_COLORS[vuln.severity]}`}>
                        {vuln.severity}
                      </span>
                      <h4 className="text-lg font-bold text-white">{vuln.title}</h4>
                      <span className="text-slate-500 font-mono text-sm">{vuln.cveId}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-white">{vuln.cvssScore}</div>
                      <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">CVSS Score</div>
                    </div>
                  </div>
                  <p className="text-sm text-slate-400 mb-4 line-clamp-2">{vuln.description}</p>
                  <div className="flex items-center justify-between border-t border-slate-800 pt-4">
                    <div className="flex gap-4 text-xs text-slate-500">
                      <span>Affected Asset: <span className="text-blue-400">PROD-DB-01</span></span>
                      <span>Detected: 2 days ago</span>
                    </div>
                    <button className="text-blue-400 text-sm font-semibold hover:text-blue-300 transition-colors">View Remediation Steps →</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {(activeTab === 'threats' || activeTab === 'scans') && (
           <div className="flex flex-col items-center justify-center py-20 glass-panel rounded-xl">
             <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 17c-.77 1.333.192 3 1.732 3z" /></svg>
             </div>
             <h3 className="text-xl font-bold text-white mb-2">Module under optimization</h3>
             <p className="text-slate-400 text-center max-w-sm">We are refining the global threat intelligence and scan engine integration. Use the Dashboard or AI Insight for current results.</p>
           </div>
        )}
      </main>

      {/* Footer / Status Bar */}
      <footer className="fixed bottom-0 left-64 right-0 h-10 border-t border-slate-800 bg-slate-900/80 backdrop-blur px-6 flex items-center justify-between z-40">
        <div className="flex gap-4 text-[10px] text-slate-500 font-bold uppercase tracking-widest">
          <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-green-500"></span> API: Latency 12ms</span>
          <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span> DB: Replicated</span>
        </div>
        <div className="text-[10px] text-slate-500">CyberVMDR v2.4.1 Enterprise | © 2024 Qualys Logic Re-imagined</div>
      </footer>
    </div>
  );
};

export default App;
