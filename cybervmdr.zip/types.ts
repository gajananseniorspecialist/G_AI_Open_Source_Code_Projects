
export enum Severity {
  CRITICAL = 'CRITICAL',
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
  INFO = 'INFO'
}

export interface Asset {
  id: string;
  hostname: string;
  ip: string;
  os: string;
  criticalCount: number;
  highCount: number;
  totalVulns: number;
  lastScan: string;
  status: 'Online' | 'Offline' | 'Scanning';
}

export interface Vulnerability {
  id: string;
  cveId: string;
  title: string;
  severity: Severity;
  cvssScore: number;
  assetId: string;
  status: 'Open' | 'Fixed' | 'Risk Accepted';
  description: string;
  solution: string;
}

export interface ScanResult {
  id: string;
  timestamp: string;
  assetsScanned: number;
  vulnsFound: number;
  duration: string;
}

export interface AIAnalysisResponse {
  summary: string;
  priorities: string[];
  remediationStrategy: string;
  riskTrend: string;
}
