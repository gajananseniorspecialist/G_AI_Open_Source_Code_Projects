
import { Asset, Severity, Vulnerability } from './types';

export const MOCK_ASSETS: Asset[] = [
  { id: '1', hostname: 'PROD-DB-01', ip: '10.0.5.21', os: 'Ubuntu 22.04 LTS', criticalCount: 2, highCount: 5, totalVulns: 12, lastScan: '2024-05-20 08:00', status: 'Online' },
  { id: '2', hostname: 'WIN-APP-SERVER', ip: '10.0.5.45', os: 'Windows Server 2022', criticalCount: 5, highCount: 12, totalVulns: 45, lastScan: '2024-05-20 09:15', status: 'Online' },
  { id: '3', hostname: 'MAIL-GW-EDGE', ip: '172.16.2.1', os: 'CentOS 7', criticalCount: 0, highCount: 2, totalVulns: 8, lastScan: '2024-05-19 22:30', status: 'Online' },
  { id: '4', hostname: 'DEV-SANDBOX', ip: '192.168.1.105', os: 'Debian 11', criticalCount: 1, highCount: 3, totalVulns: 20, lastScan: '2024-05-20 07:45', status: 'Offline' },
  { id: '5', hostname: 'AWS-S3-PROXY', ip: '10.10.1.99', os: 'Amazon Linux 2', criticalCount: 8, highCount: 15, totalVulns: 67, lastScan: '2024-05-20 10:00', status: 'Scanning' },
];

export const MOCK_VULNS: Vulnerability[] = [
  { 
    id: 'v1', 
    cveId: 'CVE-2021-44228', 
    title: 'Log4Shell RCE', 
    severity: Severity.CRITICAL, 
    cvssScore: 10.0, 
    assetId: '1', 
    status: 'Open',
    description: 'Apache Log4j2 JNDI features used in configuration, log messages, and parameters do not protect against attacker-controlled LDAP and other JNDI related endpoints.',
    solution: 'Update to Log4j 2.17.1 or higher.'
  },
  { 
    id: 'v2', 
    cveId: 'CVE-2024-3094', 
    title: 'XZ Utils Backdoor', 
    severity: Severity.CRITICAL, 
    cvssScore: 10.0, 
    assetId: '1', 
    status: 'Open',
    description: 'Malicious code was discovered in the upstream tarballs of xz, starting with version 5.6.0.',
    solution: 'Downgrade to xz-utils 5.4.x immediately.'
  },
  { 
    id: 'v3', 
    cveId: 'CVE-2023-4911', 
    title: 'Looney Tunables Glibc', 
    severity: Severity.HIGH, 
    cvssScore: 7.8, 
    assetId: '2', 
    status: 'Open',
    description: 'A buffer overflow was discovered in the GNU C Library dynamic loader GLIBC_TUNABLES environment variable handling.',
    solution: 'Apply vendor security patches.'
  }
];

export const SEVERITY_COLORS = {
  [Severity.CRITICAL]: 'bg-red-600 text-white',
  [Severity.HIGH]: 'bg-orange-500 text-white',
  [Severity.MEDIUM]: 'bg-yellow-500 text-black',
  [Severity.LOW]: 'bg-blue-500 text-white',
  [Severity.INFO]: 'bg-slate-400 text-white',
};
