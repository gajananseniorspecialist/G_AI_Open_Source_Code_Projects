
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend, AreaChart, Area 
} from 'recharts';
import { Asset, Severity } from '../types';

const VULN_DATA = [
  { name: 'Critical', value: 15, color: '#dc2626' },
  { name: 'High', value: 35, color: '#f97316' },
  { name: 'Medium', value: 85, color: '#eab308' },
  { name: 'Low', value: 120, color: '#3b82f6' },
];

const SCAN_HISTORY = [
  { day: 'Mon', vulns: 240 },
  { day: 'Tue', vulns: 210 },
  { day: 'Wed', vulns: 260 },
  { day: 'Thu', vulns: 230 },
  { day: 'Fri', vulns: 190 },
  { day: 'Sat', vulns: 180 },
  { day: 'Sun', vulns: 175 },
];

export const DashboardCharts: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
      {/* Distribution Pie */}
      <div className="glass-panel p-6 rounded-xl">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          Vulnerability Distribution
          <span className="text-xs font-normal text-slate-400">(All Assets)</span>
        </h3>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={VULN_DATA}
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {VULN_DATA.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Vulnerability Trend */}
      <div className="glass-panel p-6 rounded-xl">
        <h3 className="text-lg font-semibold mb-4">Vulnerability Detection Trend</h3>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={SCAN_HISTORY}>
              <defs>
                <linearGradient id="colorVulns" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="day" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Area type="monotone" dataKey="vulns" stroke="#3b82f6" fillOpacity={1} fill="url(#colorVulns)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
