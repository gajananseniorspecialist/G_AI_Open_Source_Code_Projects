import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("cysec.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT NOT NULL,
    status TEXT DEFAULT 'completed',
    severity_high INTEGER DEFAULT 0,
    severity_medium INTEGER DEFAULT 0,
    severity_low INTEGER DEFAULT 0,
    findings TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    ip TEXT,
    type TEXT,
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Seed data if empty
  INSERT INTO assets (name, ip, type) 
  SELECT 'Main-Gateway', '192.168.1.1', 'Router' WHERE NOT EXISTS (SELECT 1 FROM assets);
  
  INSERT INTO assets (name, ip, type) 
  SELECT 'Corp-DB-01', '10.0.0.45', 'Server' WHERE NOT EXISTS (SELECT 1 FROM assets WHERE name = 'Corp-DB-01');

  INSERT INTO assets (name, ip, type) 
  SELECT 'Dev-Workstation-X', '192.168.1.105', 'Workstation' WHERE NOT EXISTS (SELECT 1 FROM assets WHERE name = 'Dev-Workstation-X');
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/scans", (req, res) => {
    const scans = db.prepare("SELECT * FROM scans ORDER BY created_at DESC").all();
    res.json(scans);
  });

  app.post("/api/scans", (req, res) => {
    const { target, severity_high, severity_medium, severity_low, findings } = req.body;
    const stmt = db.prepare(`
      INSERT INTO scans (target, severity_high, severity_medium, severity_low, findings)
      VALUES (?, ?, ?, ?, ?)
    `);
    const info = stmt.run(target, severity_high, severity_medium, severity_low, JSON.stringify(findings));
    res.json({ id: info.lastInsertRowid });
  });

  app.get("/api/assets", (req, res) => {
    const assets = db.prepare("SELECT * FROM assets ORDER BY last_seen DESC").all();
    res.json(assets);
  });

  app.post("/api/assets", (req, res) => {
    const { name, ip, type } = req.body;
    const stmt = db.prepare("INSERT INTO assets (name, ip, type) VALUES (?, ?, ?)");
    const info = stmt.run(name, ip, type);
    res.json({ id: info.lastInsertRowid });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
