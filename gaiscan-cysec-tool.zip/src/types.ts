export interface Scan {
  id: number;
  target: string;
  status: string;
  severity_high: number;
  severity_medium: number;
  severity_low: number;
  findings: string; // JSON string
  created_at: string;
}

export interface Finding {
  id: string;
  title: string;
  severity: 'High' | 'Medium' | 'Low' | 'Critical';
  description: string;
  remediation: string;
  cve?: string;
}

export interface Asset {
  id: number;
  name: string;
  ip: string;
  type: string;
  last_seen: string;
}

export type View = 'dashboard' | 'scans' | 'assets' | 'settings';
