import React, { useState, useEffect } from 'react';
import { Search, Play, ShieldAlert, ChevronRight, Loader2, Download, ExternalLink } from 'lucide-react';
import { analyzeTarget } from '../services/geminiService';
import { Scan, Finding } from '../types';
import { motion, AnimatePresence } from 'motion/react';

export default function Scanner() {
  const [target, setTarget] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scans, setScans] = useState<Scan[]>([]);
  const [selectedScan, setSelectedScan] = useState<Scan | null>(null);

  useEffect(() => {
    fetchScans();
  }, []);

  const fetchScans = async () => {
    const res = await fetch('/api/scans');
    const data = await res.json();
    setScans(data);
  };

  const handleScan = async () => {
    if (!target) return;
    setIsScanning(true);
    try {
      const result = await analyzeTarget(target);
      
      const scanData = {
        target,
        severity_high: result.summary.high + (result.summary.critical || 0),
        severity_medium: result.summary.medium,
        severity_low: result.summary.low,
        findings: result.findings
      };

      await fetch('/api/scans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(scanData)
      });

      fetchScans();
      setTarget('');
    } catch (error) {
      console.error("Scan failed:", error);
    } finally {
      setIsScanning(false);
    }
  };

  const findings: Finding[] = selectedScan ? JSON.parse(selectedScan.findings) : [];

  return (
    <div className="p-8 h-full flex flex-col gap-8 overflow-hidden">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Vulnerability Scanner</h2>
          <p className="text-gray-500 mt-1">Execute deep-packet inspection and vulnerability analysis.</p>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-5 h-5" />
          <input 
            type="text"
            placeholder="Enter target IP, domain, or subnet (e.g., 192.168.1.1, example.com)"
            className="w-full bg-card border border-border rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-accent/50 transition-all"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            disabled={isScanning}
          />
        </div>
        <button 
          onClick={handleScan}
          disabled={isScanning || !target}
          className="bg-accent hover:bg-accent/90 disabled:opacity-50 text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2 transition-all active:scale-95"
        >
          {isScanning ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Scanning...
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              New Scan
            </>
          )}
        </button>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-8 overflow-hidden">
        {/* Scan History */}
        <div className="lg:col-span-1 bg-card border border-border rounded-2xl flex flex-col overflow-hidden">
          <div className="p-4 border-b border-border bg-white/5">
            <h3 className="font-semibold text-sm uppercase tracking-wider text-gray-400">Scan History</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-2">
            {scans.map((scan) => (
              <button
                key={scan.id}
                onClick={() => setSelectedScan(scan)}
                className={`w-full text-left p-4 rounded-xl border transition-all ${
                  selectedScan?.id === scan.id 
                    ? 'bg-accent/10 border-accent/30' 
                    : 'border-transparent hover:bg-white/5'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold truncate max-w-[150px]">{scan.target}</span>
                  <span className="text-[10px] font-mono text-gray-500">
                    {new Date(scan.created_at).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex gap-2">
                  <div className="flex items-center gap-1 text-[10px] font-bold text-high">
                    <div className="w-2 h-2 rounded-full bg-high" />
                    {scan.severity_high}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-medium">
                    <div className="w-2 h-2 rounded-full bg-medium" />
                    {scan.severity_medium}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-low">
                    <div className="w-2 h-2 rounded-full bg-low" />
                    {scan.severity_low}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Findings Detail */}
        <div className="lg:col-span-2 bg-card border border-border rounded-2xl flex flex-col overflow-hidden">
          {selectedScan ? (
            <>
              <div className="p-6 border-b border-border bg-white/5 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-bold">{selectedScan.target}</h3>
                  <p className="text-xs text-gray-500 font-mono mt-1">SCAN ID: {selectedScan.id} • COMPLETED: {new Date(selectedScan.created_at).toLocaleString()}</p>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-white/10 rounded-lg text-gray-400 transition-colors">
                    <Download className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {findings.map((finding) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={finding.id} 
                    className="border border-border rounded-xl overflow-hidden"
                  >
                    <div className="p-4 bg-white/5 flex justify-between items-center border-b border-border">
                      <div className="flex items-center gap-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          finding.severity === 'Critical' || finding.severity === 'High' ? 'bg-high/20 text-high' :
                          finding.severity === 'Medium' ? 'bg-medium/20 text-medium' : 'bg-low/20 text-low'
                        }`}>
                          {finding.severity}
                        </span>
                        <h4 className="font-semibold">{finding.title}</h4>
                      </div>
                      {finding.cve && (
                        <span className="text-[10px] font-mono bg-white/10 px-2 py-1 rounded text-gray-400">
                          {finding.cve}
                        </span>
                      )}
                    </div>
                    <div className="p-4 space-y-4">
                      <div>
                        <p className="text-xs text-gray-500 uppercase font-bold mb-1">Description</p>
                        <p className="text-sm text-gray-300 leading-relaxed">{finding.description}</p>
                      </div>
                      <div className="bg-accent/5 border border-accent/10 p-4 rounded-lg">
                        <p className="text-xs text-accent uppercase font-bold mb-1 flex items-center gap-2">
                          <ShieldAlert className="w-3 h-3" />
                          Remediation Steps
                        </p>
                        <p className="text-sm text-gray-300">{finding.remediation}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500 p-12 text-center">
              <ShieldAlert className="w-16 h-16 mb-4 opacity-20" />
              <h3 className="text-xl font-semibold text-gray-400">No Scan Selected</h3>
              <p className="max-w-xs mt-2">Select a scan from the history or start a new analysis to view vulnerability findings.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
