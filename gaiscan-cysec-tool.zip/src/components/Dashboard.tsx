import React, { useEffect, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Shield, AlertTriangle, Info, Zap } from 'lucide-react';
import { Scan } from '../types';

export default function Dashboard() {
  const [scans, setScans] = useState<Scan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/scans')
      .then(res => res.json())
      .then(data => {
        setScans(data);
        setLoading(false);
      });
  }, []);

  const totalHigh = scans.reduce((acc, s) => acc + s.severity_high, 0);
  const totalMedium = scans.reduce((acc, s) => acc + s.severity_medium, 0);
  const totalLow = scans.reduce((acc, s) => acc + s.severity_low, 0);

  const severityData = [
    { name: 'High', value: totalHigh, color: '#f97316' },
    { name: 'Medium', value: totalMedium, color: '#eab308' },
    { name: 'Low', value: totalLow, color: '#22c55e' },
  ];

  const recentScansData = scans.slice(0, 5).map(s => ({
    name: s.target,
    high: s.severity_high,
    medium: s.severity_medium,
    low: s.severity_low,
  }));

  const stats = [
    { label: 'Total Scans', value: scans.length, icon: Zap, color: 'text-accent' },
    { label: 'Critical Issues', value: totalHigh, icon: AlertTriangle, color: 'text-high' },
    { label: 'Network Assets', value: 12, icon: Shield, color: 'text-low' },
    { label: 'Risk Score', value: 'B+', icon: Info, color: 'text-medium' },
  ];

  if (loading) return <div className="p-8 animate-pulse text-gray-500 font-mono">INITIALIZING DASHBOARD...</div>;

  return (
    <div className="p-8 space-y-8 overflow-y-auto h-full">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Security Overview</h2>
          <p className="text-gray-500 mt-1">Real-time security posture and vulnerability metrics.</p>
        </div>
        <div className="text-right font-mono text-xs text-gray-500">
          LAST UPDATED: {new Date().toLocaleTimeString()}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-card border border-border p-6 rounded-2xl">
            <div className="flex justify-between items-start mb-4">
              <div className={`p-2 rounded-lg bg-white/5 ${stat.color}`}>
                <stat.icon className="w-5 h-5" />
              </div>
            </div>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs text-gray-500 uppercase tracking-wider mt-1">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-card border border-border p-6 rounded-2xl">
          <h3 className="text-lg font-semibold mb-6">Vulnerability Distribution</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151518', border: '1px solid #27272a', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            {severityData.map(d => (
              <div key={d.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
                <span className="text-xs text-gray-400">{d.name}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border p-6 rounded-2xl">
          <h3 className="text-lg font-semibold mb-6">Recent Scan Severity</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={recentScansData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="name" stroke="#52525b" fontSize={12} />
                <YAxis stroke="#52525b" fontSize={12} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151518', border: '1px solid #27272a', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Bar dataKey="high" fill="#f97316" radius={[4, 4, 0, 0]} />
                <Bar dataKey="medium" fill="#eab308" radius={[4, 4, 0, 0]} />
                <Bar dataKey="low" fill="#22c55e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
