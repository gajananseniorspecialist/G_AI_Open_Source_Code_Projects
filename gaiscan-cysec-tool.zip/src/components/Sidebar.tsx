import React from 'react';
import { 
  LayoutDashboard, 
  ShieldAlert, 
  Network, 
  Settings, 
  Terminal,
  Activity
} from 'lucide-react';
import { View } from '../types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SidebarProps {
  currentView: View;
  onViewChange: (view: View) => void;
}

export default function Sidebar({ currentView, onViewChange }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'scans', label: 'Vulnerability Scans', icon: ShieldAlert },
    { id: 'assets', label: 'Asset Inventory', icon: Network },
    { id: 'settings', label: 'Settings', icon: Settings },
  ] as const;

  return (
    <div className="w-64 border-r border-border h-screen flex flex-col bg-bg/50 backdrop-blur-xl">
      <div className="p-6 flex items-center gap-3 border-b border-border">
        <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
          <Terminal className="text-white w-5 h-5" />
        </div>
        <div>
          <h1 className="font-bold text-lg tracking-tight">GAIScan</h1>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">CySec Tool v1.0</p>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id as View)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
              currentView === item.id 
                ? "bg-accent/10 text-accent border border-accent/20" 
                : "text-gray-400 hover:bg-white/5 hover:text-white"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5 transition-transform duration-200",
              currentView === item.id ? "scale-110" : "group-hover:scale-110"
            )} />
            <span className="font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-border">
        <div className="bg-card p-4 rounded-xl border border-border">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-low" />
            <span className="text-xs font-medium text-gray-300">System Status</span>
          </div>
          <div className="h-1 w-full bg-border rounded-full overflow-hidden">
            <div className="h-full bg-low w-full animate-pulse" />
          </div>
          <p className="text-[10px] text-gray-500 mt-2 font-mono">ALL SYSTEMS OPERATIONAL</p>
        </div>
      </div>
    </div>
  );
}
