import React, { useState, useEffect } from 'react';
import { Network, Server, Laptop, ShieldCheck, MoreVertical, Search, Plus } from 'lucide-react';
import { Asset } from '../types';

export default function Assets() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/assets')
      .then(res => res.json())
      .then(data => {
        setAssets(data);
        setLoading(false);
      });
  }, []);

  const getIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'server': return Server;
      case 'workstation': return Laptop;
      default: return Network;
    }
  };

  return (
    <div className="p-8 space-y-8 h-full flex flex-col">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Asset Inventory</h2>
          <p className="text-gray-500 mt-1">Discovered network assets and their security status.</p>
        </div>
        <button className="bg-white/5 hover:bg-white/10 border border-border text-white px-4 py-2 rounded-xl font-medium flex items-center gap-2 transition-all">
          <Plus className="w-4 h-4" />
          Add Asset
        </button>
      </div>

      <div className="bg-card border border-border rounded-2xl flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-border flex justify-between items-center bg-white/5">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search assets..." 
              className="w-full bg-bg border border-border rounded-lg py-1.5 pl-9 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-accent"
            />
          </div>
          <div className="flex gap-2">
            <span className="text-xs text-gray-500 font-mono">TOTAL ASSETS: {assets.length}</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-card border-b border-border z-10">
              <tr>
                <th className="px-6 py-4 text-xs font-bold uppercase text-gray-500 tracking-wider">Asset Name</th>
                <th className="px-6 py-4 text-xs font-bold uppercase text-gray-500 tracking-wider">IP Address</th>
                <th className="px-6 py-4 text-xs font-bold uppercase text-gray-500 tracking-wider">Type</th>
                <th className="px-6 py-4 text-xs font-bold uppercase text-gray-500 tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-bold uppercase text-gray-500 tracking-wider">Last Seen</th>
                <th className="px-6 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {assets.length > 0 ? assets.map((asset) => {
                const Icon = getIcon(asset.type);
                return (
                  <tr key={asset.id} className="hover:bg-white/5 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-white/5 text-gray-400 group-hover:text-accent transition-colors">
                          <Icon className="w-4 h-4" />
                        </div>
                        <span className="font-medium">{asset.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-mono text-sm text-gray-400">{asset.ip}</td>
                    <td className="px-6 py-4">
                      <span className="text-xs bg-white/5 px-2 py-1 rounded border border-border text-gray-400 uppercase tracking-wider">
                        {asset.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-low shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
                        <span className="text-xs text-low font-medium uppercase">Protected</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs text-gray-500 font-mono">
                      {new Date(asset.last_seen).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 hover:bg-white/10 rounded-lg text-gray-500 transition-colors">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center gap-2">
                      <Network className="w-8 h-8 opacity-20" />
                      <p>No assets discovered yet.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
