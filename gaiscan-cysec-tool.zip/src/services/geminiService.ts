import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const analyzeTarget = async (target: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Perform a simulated security vulnerability scan on the target: ${target}. 
    Provide a list of realistic vulnerabilities that might be found on such a target. 
    Include CVE IDs if applicable. 
    Return the data in a structured format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          findings: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                severity: { type: Type.STRING, enum: ["Critical", "High", "Medium", "Low"] },
                description: { type: Type.STRING },
                remediation: { type: Type.STRING },
                cve: { type: Type.STRING }
              },
              required: ["id", "title", "severity", "description", "remediation"]
            }
          },
          summary: {
            type: Type.OBJECT,
            properties: {
              high: { type: Type.INTEGER },
              medium: { type: Type.INTEGER },
              low: { type: Type.INTEGER },
              critical: { type: Type.INTEGER }
            }
          }
        }
      }
    }
  });

  return JSON.parse(response.text);
};
