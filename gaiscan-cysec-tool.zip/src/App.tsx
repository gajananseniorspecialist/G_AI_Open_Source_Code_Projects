import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Scanner from './components/Scanner';
import Assets from './components/Assets';
import { View } from './types';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <Dashboard />;
      case 'scans': return <Scanner />;
      case 'assets': return <Assets />;
      case 'settings': return (
        <div className="p-8">
          <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
          <p className="text-gray-500 mt-1">Configure scanner parameters and API integrations.</p>
          <div className="mt-8 p-12 border border-dashed border-border rounded-2xl text-center text-gray-500">
            System configuration modules are restricted to administrative users.
          </div>
        </div>
      );
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-bg text-gray-100 overflow-hidden">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-1 relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
