
import React, { useState, useEffect, useCallback } from 'react';
import CalculatorButton from './components/CalculatorButton';
import { Operator } from './types';

const App: React.FC = () => {
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [firstOperand, setFirstOperand] = useState<number | null>(null);
  const [operator, setOperator] = useState<Operator | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState<boolean>(false);

  const inputDigit = useCallback((digit: string) => {
    if (waitingForOperand) {
      setDisplayValue(digit);
      setWaitingForOperand(false);
    } else {
      setDisplayValue(prev => (prev === '0' ? digit : prev + digit));
    }
  }, [waitingForOperand]);

  const inputDot = useCallback(() => {
    if (waitingForOperand) {
      setDisplayValue('0.');
      setWaitingForOperand(false);
      return;
    }
    if (!displayValue.includes('.')) {
      setDisplayValue(prev => prev + '.');
    }
  }, [displayValue, waitingForOperand]);

  const clearAll = useCallback(() => {
    setDisplayValue('0');
    setFirstOperand(null);
    setOperator(null);
    setWaitingForOperand(false);
  }, []);

  const toggleSign = useCallback(() => {
    const value = parseFloat(displayValue);
    setDisplayValue((value * -1).toString());
  }, [displayValue]);

  const inputPercent = useCallback(() => {
    const value = parseFloat(displayValue);
    setDisplayValue((value / 100).toString());
  }, [displayValue]);

  const performCalculation = (op: Operator, nextValue: number): number => {
    if (firstOperand === null) return nextValue;
    
    switch (op) {
      case '÷': return firstOperand / nextValue;
      case '×': return firstOperand * nextValue;
      case '+': return firstOperand + nextValue;
      case '-': return firstOperand - nextValue;
      default: return nextValue;
    }
  };

  const handleOperator = useCallback((nextOperator: Operator) => {
    const inputValue = parseFloat(displayValue);

    if (firstOperand === null) {
      setFirstOperand(inputValue);
    } else if (operator) {
      const result = performCalculation(operator, inputValue);
      setFirstOperand(result);
      setDisplayValue(String(result));
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  }, [displayValue, firstOperand, operator]);

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const { key } = e;
      if (/[0-9]/.test(key)) inputDigit(key);
      if (key === '.') inputDot();
      if (key === 'Enter' || key === '=') handleOperator('=');
      if (key === 'Escape' || key === 'Backspace') clearAll();
      if (key === '+') handleOperator('+');
      if (key === '-') handleOperator('-');
      if (key === '*') handleOperator('×');
      if (key === '/') handleOperator('÷');
      if (key === '%') inputPercent();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [inputDigit, inputDot, handleOperator, clearAll, inputPercent]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 sm:p-0">
      <div className="bg-black w-full max-w-[350px] sm:max-w-[380px] p-6 rounded-[40px] shadow-2xl flex flex-col gap-4">
        
        {/* Display Area */}
        <div className="h-32 sm:h-40 flex items-end justify-end px-4 mb-2 overflow-hidden">
          <div className="text-white text-7xl sm:text-8xl font-light tracking-tight transition-all duration-200 truncate">
            {displayValue.length > 9 ? parseFloat(displayValue).toPrecision(5) : displayValue}
          </div>
        </div>

        {/* Buttons Grid */}
        <div className="grid grid-cols-4 gap-3 sm:gap-4">
          <CalculatorButton 
            label={displayValue === '0' ? 'AC' : 'C'} 
            variant="function" 
            onClick={clearAll} 
          />
          <CalculatorButton 
            label="+/-" 
            variant="function" 
            onClick={toggleSign} 
          />
          <CalculatorButton 
            label="%" 
            variant="function" 
            onClick={inputPercent} 
          />
          <CalculatorButton 
            label="÷" 
            variant="operator" 
            isActive={operator === '÷'} 
            onClick={() => handleOperator('÷')} 
          />

          <CalculatorButton label="7" onClick={() => inputDigit('7')} />
          <CalculatorButton label="8" onClick={() => inputDigit('8')} />
          <CalculatorButton label="9" onClick={() => inputDigit('9')} />
          <CalculatorButton 
            label="×" 
            variant="operator" 
            isActive={operator === '×'} 
            onClick={() => handleOperator('×')} 
          />

          <CalculatorButton label="4" onClick={() => inputDigit('4')} />
          <CalculatorButton label="5" onClick={() => inputDigit('5')} />
          <CalculatorButton label="6" onClick={() => inputDigit('6')} />
          <CalculatorButton 
            label="-" 
            variant="operator" 
            isActive={operator === '-'} 
            onClick={() => handleOperator('-')} 
          />

          <CalculatorButton label="1" onClick={() => inputDigit('1')} />
          <CalculatorButton label="2" onClick={() => inputDigit('2')} />
          <CalculatorButton label="3" onClick={() => inputDigit('3')} />
          <CalculatorButton 
            label="+" 
            variant="operator" 
            isActive={operator === '+'} 
            onClick={() => handleOperator('+')} 
          />

          {/* Bottom Row */}
          <div className="col-span-2">
            <CalculatorButton 
              label="0" 
              isDouble={true} 
              onClick={() => inputDigit('0')} 
            />
          </div>
          <CalculatorButton label="." onClick={inputDot} />
          <CalculatorButton 
            label="=" 
            variant="operator" 
            onClick={() => handleOperator('=')} 
          />
        </div>
      </div>
      
      {/* Attribution/Hint */}
      <p className="mt-8 text-neutral-600 text-sm font-medium tracking-wide">
        DESIGNED BY APPLE IN CALIFORNIA (WEB CLONE)
      </p>
    </div>
  );
};

export default App;
