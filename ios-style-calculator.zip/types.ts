
export type Operator = '+' | '-' | '×' | '÷' | '=';

export interface CalculatorState {
  displayValue: string;
  operator: Operator | null;
  firstOperand: number | null;
  waitingForOperand: boolean;
}
