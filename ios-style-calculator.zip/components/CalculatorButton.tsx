
import React from 'react';

interface CalculatorButtonProps {
  label: string;
  onClick: () => void;
  variant?: 'number' | 'operator' | 'function';
  isDouble?: boolean;
  isActive?: boolean;
}

const CalculatorButton: React.FC<CalculatorButtonProps> = ({
  label,
  onClick,
  variant = 'number',
  isDouble = false,
  isActive = false,
}) => {
  let baseClasses = "flex items-center justify-center rounded-full text-3xl font-medium transition-all active:opacity-70 duration-100";
  
  // Size classes
  const sizeClasses = isDouble 
    ? "w-[158px] h-[72px] sm:w-[176px] sm:h-[80px] rounded-[40px] justify-start pl-8" 
    : "w-[72px] h-[72px] sm:w-[80px] sm:h-[80px]";

  // Color variants
  let colorClasses = "";
  switch (variant) {
    case 'function':
      colorClasses = "bg-[#a5a5a5] text-black hover:bg-[#d4d4d2]";
      break;
    case 'operator':
      colorClasses = isActive 
        ? "bg-white text-[#ff9f0a]" 
        : "bg-[#ff9f0a] text-white hover:bg-[#ffb340]";
      break;
    case 'number':
    default:
      colorClasses = "bg-[#333333] text-white hover:bg-[#666666]";
      break;
  }

  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${sizeClasses} ${colorClasses}`}
    >
      {label}
    </button>
  );
};

export default CalculatorButton;
